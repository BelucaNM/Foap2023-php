<footer>
<div id="avisoLegal">
    <p class="aviso"><b>AVISO LEGAL:</b> En cumplimiento del artículo 10 de la Ley 34 / 2002, de 11 de julio, de Servicios de la Sociedad de la Información y Comercio Electrónico, 
    el Titular, Isabel Luisa Navarrina Martínez, expone sus datos identificativos.
    /(No procede registro mercantil/)
    NIF: 00000000L, Domicilio: Serra del Cadi, en Olivella Correo electrónico: isabel.navarrina@gmail.com</p>
    <p class="aviso">La <strong>finalidad </strong>del sitio Web ExamenPracticPHP.html es de ejercicio práctico de PHP .</p>
</div>
</footer>