<header>
    <div id="header">
        <h1> <span><img id="logo" src=".\laXarxaImagenes\logo.jpg"></span> La Xarxa </h1>
    </div>
</header>